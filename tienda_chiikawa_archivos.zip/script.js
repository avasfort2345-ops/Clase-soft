let cartCount = 0;

function addToCart(productName) {
    // Incrementar contador
    cartCount++;
    document.getElementById('cart-count').innerText = cartCount;

    // Mostrar Toast Notification
    const toast = document.getElementById("toast");
    toast.innerText = "¡" + productName + " añadido al carrito! 🌸";
    toast.className = "show";
    
    // Ocultar Toast después de 3 segundos
    setTimeout(function(){ 
        toast.className = toast.className.replace("show", ""); 
    }, 3000);
}
